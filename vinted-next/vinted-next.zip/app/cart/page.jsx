'use client';

import React, { useContext, useState } from 'react';
import { useRouter, useParams, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import {
    FaShoppingCart, FaTrash, FaCheckSquare, FaSquare,
    FaArrowRight, FaTag, FaBoxOpen, FaChevronRight,
    FaShieldAlt, FaTruck, FaLock
} from 'react-icons/fa';
import { useCart } from '@/context/CartContext';
import CurrencyContext from '@/context/CurrencyContext';
import AuthContext from '@/context/AuthContext';
import { getImageUrl, getItemImageUrl, safeString } from '@/utils/constants';
import { usePopup } from '@/components/common/Popup';
import Meta from '@/components/common/Meta';
import { useTranslation } from 'react-i18next';
import '@/app/styles/Cart.css';

const SHIPPING_FEE = 200; // ₹200 temp flat fee

const Cart = () => {
    const navigate = useRouter();
    const { t } = useTranslation();
    const { user } = useContext(AuthContext);
    const { formatPrice, currencies, defaultCurrency } = useContext(CurrencyContext);
    const {
        cartItems, removeFromCart, toggleSelect, selectAll,
        deselectAll, selectedItems, cartCount, removeSelected
    } = useCart();
    const { showPopup, PopupComponent } = usePopup();

    const allSelected = cartItems.length > 0 && cartItems.every(item => item.selected);

    // Helper to group items by seller
    const groupedItems = cartItems.reduce((groups, item) => {
        const sellerId = item.seller_id?._id || item.seller_id;
        const sellerName = safeString(item.seller_id?.username) || t('cart.unknown_seller', 'Unknown Seller');
        if (!groups[sellerId]) groups[sellerId] = { items: [], sellerName, seller: item.seller_id };
        groups[sellerId].items.push(item);
        return groups;
    }, {});

    // Calculate bundle-aware totals
    const calculateBundleTotals = () => {
        let subtotal = 0; // In default currency
        let shippingTotal = 0; // In default currency
        let discountTotal = 0; // In default currency

        const getInDefault = (price, currId) => {
            if (!price) return 0;
            if (!defaultCurrency?.exchange_rate) return price;
            
            const targetCurr = currencies.find(c => 
                c._id === (currId?._id || currId) || 
                c.code?.toLowerCase() === (currId?.code || currId || '').toString().toLowerCase()
            );
            
            // If it's 'inr' and not found in list, use rate 1.0 (internal base)
            const itemRate = targetCurr ? targetCurr.exchange_rate : (currId === 'inr' || currId?.code === 'INR' ? 1 : defaultCurrency.exchange_rate);
            
            return (price / itemRate) * defaultCurrency.exchange_rate;
        };

        // Group selected items by seller to calculate shipping and discounts
        const selectedBySeller = selectedItems.reduce((acc, item) => {
            const sid = item.seller_id?._id || item.seller_id;
            if (!acc[sid]) acc[sid] = { items: [], seller: item.seller_id };
            acc[sid].items.push(item);
            return acc;
        }, {});

        Object.values(selectedBySeller).forEach(group => {
            const { items, seller } = group;
            if (items.length === 0) return;

            // 1. Add item prices to subtotal
            items.forEach(item => {
                subtotal += getInDefault(item.price, item.currency_id);
            });

            // 2. Calculate Combined Shipping (200 INR per seller if not free)
            const anyFreeShipping = items.some(i => i.shipping_included);
            if (!anyFreeShipping) {
                // SHIPPING_FEE in backend is 200 INR
                shippingTotal += getInDefault(SHIPPING_FEE, 'inr');
            }

            // 3. Calculate Bundle Discount
            if (seller && seller.bundle_discounts?.enabled) {
                const count = items.length;
                let pct = 0;
                if (count >= 5) pct = seller.bundle_discounts.five_items;
                else if (count >= 3) pct = seller.bundle_discounts.three_items;
                else if (count >= 2) pct = seller.bundle_discounts.two_items;

                if (pct > 0) {
                    const groupSubtotal = items.reduce((s, i) => s + getInDefault(i.price, i.currency_id), 0);
                    discountTotal += (groupSubtotal * pct) / 100;
                }
            }
        });

        return { subtotal, shippingTotal, discountTotal, total: subtotal + shippingTotal - discountTotal };
    };

    const { subtotal, shippingTotal, discountTotal, total } = calculateBundleTotals();

    const handleRemove = (item) => {
        showPopup({
            type: 'confirm',
            title: t('cart.remove_item_title', 'Remove Item?'),
            message: t('cart.remove_item_msg', 'Remove "{{item}}" from your cart?').replace('{{item}}', item.title),
            confirmText: t('cart.remove', 'Remove'),
            cancelText: t('cart.keep', 'Keep'),
            onConfirm: () => removeFromCart(item._id)
        });
    };

    const handleRemoveSelected = () => {
        if (selectedItems.length === 0) return;
        showPopup({
            type: 'confirm',
            title: t('cart.remove_items_title', 'Remove {{count}} item(s)?').replace('{{count}}', selectedItems.length),
            message: t('cart.remove_items_msg', 'These items will be removed from your cart.'),
            confirmText: t('cart.remove', 'Remove'),
            cancelText: t('cart.cancel', 'Cancel'),
            onConfirm: removeSelected
        });
    };

    const handleCheckout = () => {
        if (!user) {
            showPopup({ type: 'warning', title: t('cart.login_required_title', 'Login Required'), message: t('cart.login_required_msg', 'Please log in to proceed to checkout.') });
            return;
        }
        if (selectedItems.length === 0) {
            showPopup({ type: 'info', title: t('cart.no_items_title', 'No Items Selected'), message: t('cart.no_items_msg', 'Please select at least one item to checkout.') });
            return;
        }
        navigate.push('/checkout');
    };

    if (!user) {
        return (
            <div className="cart-page">
                <div className="cart-empty-state">
                    <div className="cart-empty-icon"><FaShoppingCart /></div>
                    <p>{t('cart.login_required', 'You need to be logged in to manage your shopping cart.')}</p>
                    <Link href="/login" className="cart-shop-btn">{t('cart.login_btn', 'Log In / Sign Up')}</Link>
                </div>
                <PopupComponent />
            </div>
        );
    }

    if (cartItems.length === 0) {
        return (
            <div className="cart-page">
                <div className="cart-empty-state">
                    <div className="cart-empty-icon"><FaShoppingCart /></div>
                    <h2>{t('cart.empty_cart', 'Your cart is empty')}</h2>
                    <p>{t('cart.start_shopping', 'Browse items and add them to your cart to get started.')}</p>
                    <Link href="/products" className="cart-shop-btn">{t('cart.browse_items', 'Browse Items')}</Link>
                </div>
                <PopupComponent />
            </div>
        );
    }

    return (
        <div className="cart-page">
            
            <div className="cart-container">
                {/* Breadcrumb */}
                <div className="cart-breadcrumb">
                    <Link href="/products">Home</Link> <FaChevronRight size={10} />
                    <span>{t('cart.shopping_cart', 'Shopping Cart')}</span>
                </div>

                <div className="cart-grid">
                    <div className="cart-items-panel">
                        <h1 className="cart-main-title">
                            <FaShoppingCart /> {t('cart.shopping_cart', 'Shopping Cart')}
                        </h1>
                        <span className="cart-count-badge">{cartCount}</span>
                        {selectedItems.length > 1 && (
                            <div className="cart-bundle-badge">
                                <FaTag /> {t('cart.bundle_discovery', 'Bundle Discovery: Multiple items from same seller group automatically!')}
                            </div>
                        )}
                        {/* Toolbar */}
                        <div className="cart-toolbar">
                            <button className="cart-global-select" onClick={allSelected ? deselectAll : selectAll}>
                                {allSelected
                                    ? <><FaCheckSquare className="cart-check-icon checked" /> {t('cart.deselect_all', 'Deselect All')}</>
                                    : <><FaSquare className="cart-check-icon" /> {t('cart.select_all', 'Select All')}</>
                                }
                            </button>
                            {selectedItems.length > 0 && (
                                <button className="cart-global-remove" onClick={handleRemoveSelected}>
                                    <FaTrash /> {t('cart.remove_selected_count', 'Remove Selected ({{count}})').replace('{{count}}', selectedItems.length)}
                                </button>
                            )}
                        </div>

                        {/* Grouped Items */}
                        <div className="cart-groups-list">
                            {Object.entries(groupedItems).map(([sellerId, group]) => {
                                const selectedInGroup = group.items.filter(i => i.selected);
                                const hasDiscount = group.seller?.bundle_discounts?.enabled && selectedInGroup.length >= 2;

                                return (
                                    <div key={sellerId} className="cart-seller-group">
                                        <div className="cart-group-header-right">
                                            <span className="cart-seller-name">{group.sellerName}</span>
                                            <span className="cart-seller-badge">{t('cart.seller', 'SELLER')}</span>
                                        </div>
                                        <div className="cart-items-list">
                                            {group.items.map(item => {
                                                const imgUrl = getItemImageUrl(item.images?.[0]);
                                                const isSold = item.is_sold || item.status === 'sold' || item.is_ordered;
                                                return (
                                                    <div
                                                        key={item._id}
                                                        className={`cart-item-row ${item.selected ? 'selected' : ''} ${isSold ? 'sold' : ''}`}
                                                    >
                                                        {/* Checkbox */}
                                                        {!isSold ? (
                                                            <button
                                                                className="cart-item-check"
                                                                onClick={() => toggleSelect(item._id)}
                                                                aria-label={item.selected ? 'Deselect' : 'Select'}
                                                            >
                                                                {item.selected
                                                                    ? <FaCheckSquare className="cart-check-icon checked" />
                                                                    : <FaSquare className="cart-check-icon" />
                                                                }
                                                            </button>
                                                        ) : (
                                                            <div className="cart-item-check-placeholder" style={{ width: '24px', marginRight: '15px' }}></div>
                                                        )}

                                                        {/* Image */}
                                                        <Link href={`/items/${item.slug || item._id}`} className="cart-item-img-link">
                                                            <img src={imgUrl} alt={safeString(item.title)} className="cart-item-img" style={isSold ? { filter: 'grayscale(100%)' } : {}} />
                                                        </Link>

                                                        {/* Info */}
                                                        <div className="cart-item-info">
                                                            <Link href={`/items/${item.slug || item._id}`} className="cart-item-title">
                                                                {safeString(item.title)}
                                                            </Link>
                                                            <div className="cart-item-meta">
                                                                {item.condition && <span className="cart-meta-chip">{item.condition}</span>}
                                                                {item.size && <span className="cart-meta-chip">{t('cart.size', 'Size:')} {item.size}</span>}
                                                            </div>
                                                            {isSold && (
                                                                <div className="cart-item-sold-tag">
                                                                    {t('cart.ordered', 'ORDERED')}
                                                                </div>
                                                            )}
                                                            <div className="cart-item-shipping-note">
                                                                {item.shipping_included && <span className="ship-free">{t('cart.free_shipping', 'Free shipping')}</span>}
                                                            </div>
                                                        </div>

                                                        {/* Price */}
                                                        <div className="cart-item-price-col">
                                                            <div className="cart-item-price">
                                                                {formatPrice(item.price, item.currency_id)}
                                                            </div>
                                                        </div>

                                                        {/* Remove */}
                                                        <button
                                                            className="cart-item-remove"
                                                            onClick={() => handleRemove(item)}
                                                            aria-label="Remove"
                                                        >
                                                            <FaTrash />
                                                        </button>
                                                    </div>
                                                );
                                            })}
                                        </div>

                                        {selectedInGroup.length > 0 && (
                                            <div className="cart-group-footer">
                                                <div className="cart-group-shipping-info">
                                                    <FaTruck />
                                                    {selectedInGroup.some(i => i.shipping_included)
                                                        ? ` ${t('cart.combined_shipping_free', 'Combined shipping: Free')}`
                                                        : ` ${t('cart.combined_shipping_cost', 'Combined shipping:')} ${formatPrice(SHIPPING_FEE)}`
                                                    }
                                                </div>
                                                {hasDiscount && (
                                                    <div className="cart-group-discount-info">
                                                        <FaTag /> {t('cart.bundle_savings', 'Bundle savings applied!')}
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    </div>

                    {/* ── Right: Order Summary ── */}
                    <aside className="cart-summary-panel">
                        <div className="cart-summary-card">
                            <h2 className="cart-summary-title">{t('cart.order_summary', 'Order Summary')}</h2>

                            <div className="cart-summary-row">
                                <span>{t('cart.subtotal', 'Subtotal')}</span>
                                <span>{formatPrice(subtotal)}</span>
                            </div>
                            <div className="cart-summary-row">
                                <span>{t('cart.combined_shipping', 'Combined Shipping')}</span>
                                <span className={shippingTotal === 0 ? 'cart-free-tag' : ''}>
                                    {shippingTotal === 0 ? t('cart.free', 'FREE') : formatPrice(shippingTotal)}
                                </span>
                            </div>
                            {discountTotal > 0 && (
                                <div className="cart-summary-row cart-discount-row">
                                    <span>{t('cart.bundle_discount', 'Bundle Discount')}</span>
                                    <span>-{formatPrice(discountTotal)}</span>
                                </div>
                            )}

                            <div className="cart-summary-divider" />

                            <div className="cart-summary-row cart-summary-total">
                                <span>{t('cart.to_pay', 'To Pay')}</span>
                                <span>{formatPrice(total)}</span>
                            </div>

                            <button
                                className="cart-checkout-btn"
                                onClick={handleCheckout}
                                disabled={selectedItems.length === 0}
                            >
                                {t('cart.checkout_count', 'Checkout ({{count}})').replace('{{count}}', selectedItems.length)} <FaArrowRight />
                            </button>


                            <div className="cart-trust-row">
                                <span><FaShieldAlt /> {t('cart.buyer_protection', 'Buyer Protection')}</span>
                                <span><FaLock /> {t('cart.secure_payment', 'Secure Payment')}</span>
                            </div>
                        </div>

                        {/* Selected Items preview */}
                        {selectedItems.length > 0 && (
                            <div className="cart-selected-preview">
                                <p className="cart-preview-label">{t('cart.selected_items', 'Selected Items')}</p>
                                {selectedItems.map(item => (
                                    <div key={item._id} className="cart-preview-row">
                                        <img
                                            src={getItemImageUrl(item.images?.[0])}
                                            alt={safeString(item.title)}
                                        />
                                        <span className="cart-preview-name">{safeString(item.title)}</span>
                                        <span className="cart-preview-price">{formatPrice(item.price, item.currency_id)}</span>
                                    </div>
                                ))}
                            </div>
                        )}
                    </aside>
                </div>
            </div>
            <PopupComponent />
        </div>
    );
};

export default function CartPage() { return <Cart />; }
