import React, { Suspense } from 'react';
import ItemDetailContent from '@/components/items/ItemDetailContent';

import { BASE_URL, getImageUrl } from '@/utils/constants';

export async function generateMetadata({ params }) {
  const { id } = await params;
  try {
    // Fetch item details from API
    const res = await fetch(`${BASE_URL}/api/items/${id}`, { cache: 'no-store' });
    if (!res.ok) throw new Error('Item not found');
    const item = await res.json();
    
    if (!item || !item.title) return { title: 'Item Not Found' };

    const title = item.title;
    const description = item.short_description || item.description?.substring(0, 160) || `Buy ${item.title} on our marketplace.`;
    const image = item.images && item.images[0] ? getImageUrl(item.images[0]) : null;

    return {
      title: `${title} | Marketplace`,
      description,
      openGraph: {
        title: `${title} | Marketplace`,
        description,
        url: `${BASE_URL}/items/${item.slug || id}`,
        siteName: 'Marketplace',
        images: image ? [{ url: image, width: 800, height: 600, alt: title }] : [],
        type: 'website',
      },
      twitter: {
        card: 'summary_large_image',
        title: `${title} | Marketplace`,
        description,
        images: image ? [image] : [],
      },
    };
  } catch (error) {
    console.error('Metadata fetch error:', error);
    return {
      title: 'Item Details',
      description: 'Explore this item on our marketplace.',
    };
  }
}

export default function ItemPage() {
  return (
    <Suspense fallback={<div className="container mt-5 pt-5 text-center">Loading item details...</div>}>
      <ItemDetailContent />
    </Suspense>
  );
}
