import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:5003',
        changeOrigin: true,
      },
      '/images': {
        target: 'http://localhost:5003',
        changeOrigin: true,
      },
      '/socket.io': {
        target: 'http://localhost:5003',
        ws: true,
        changeOrigin: true,
      },
    }
  }
})
